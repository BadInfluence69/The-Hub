THE HUB — Roku App (Fixed)
==========================

HOW THIS WORKS
--------------
The Roku app connects to your Flask server (app.py) running on your computer.
It calls two endpoints:

  1. GET /api/roku/search?q=<query>
     Returns a JSON list of video titles + stream resolver URLs.
     The app shows these as a thumbnail grid on your TV.

  2. GET /api/roku/stream/<video_id>
     When you select a video, the Roku Video node hits this URL.
     Flask calls yt-dlp to resolve the real YouTube CDN stream URL
     and 307-redirects the Roku player directly to it.
     The Roku streams from YouTube's CDN — no proxying through your PC.

SETUP STEPS
-----------
1. Make sure app.py is running on your computer:
      python app.py
   It will listen on 0.0.0.0:5002 (accessible from your TV).

2. Confirm your computer's local IP is still 192.168.0.142.
   If it changed, update this line in components/MainScene.brs:
      computerIP = "192.168.0.142"
   And this line in app.py inside api_roku_search() and api_roku_stream():
      "url": f"http://192.168.0.142:{LISTENING_PORT}/api/roku/stream/{video_id}"

3. Make sure your Roku TV is in Developer Mode:
   - Home x3, Up, Right, Left, Right, Left, Right
   - Go to http://<roku-ip>:8060 from your browser

4. Zip the project and sideload it:
      cd roku_app_fixed
      zip -r TheHub.zip . -x "*.DS_Store"
   Upload TheHub.zip at http://<roku-ip> → Developer Application Installer

REMOTE CONTROLS
---------------
  OK / Select  → Play selected video
  Back         → Stop video, return to grid
  * (Options)  → Open search keyboard

FOLDER STRUCTURE
----------------
  manifest
  source/main.brs
  components/MainScene.xml
  components/MainScene.brs
  components/SearchTask.xml
  components/SimpleGridItem.xml
  images/icon.png
